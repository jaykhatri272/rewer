from flask import Flask, request, jsonify, render_template

app = Flask(__name__)

# Updated questions with more entries
questions = [{
    "question":
    "What are you interested in? (e.g., Technology, Arts, Science, Business, Medicine)",
    "options": {
        "Technology":
        ["Software Developer", "Data Scientist", "Cybersecurity Analyst", "Cloud Engineer"],
        "Arts": ["Graphic Designer", "Content Creator", "Photographer"],
        "Science": ["Biologist", "Chemist", "Physicist"],
        "Business": ["Marketing Manager", "Financial Analyst", "Entrepreneur"],
        "Medicine": ["Doctor", "Dentist", "Pharmacist"]
    }
}, {
    "question":
    "What is your strongest skill? (e.g., Problem-solving, Creativity, Analytical thinking, Communication, Leadership, Technical skills)",
    "options": {
        "Problem-solving": ["Engineer", "Data Scientist", "Consultant"],
        "Creativity": ["Artist", "Designer", "Content Creator"],
        "Analytical thinking":
        ["Data Analyst", "Financial Analyst", "Research Scientist"],
        "Communication":
        ["Public Relations Specialist", "Sales Manager", "Teacher"],
        "Leadership": ["Project Manager", "Team Lead", "Entrepreneur"],
        "Technical skills": [
            "Software Developer", "Cybersecurity Analyst",
            "Cloud Engineer"
        ]
    }
}, {
    "question":
    "Do you prefer working in a team or alone? (Type 'team', 'alone', or 'both')",
    "options": {
        "team": ["Project Manager", "Team Lead", "Salesperson"],
        "alone": ["Researcher", "Data Scientist", "Analyst"],
        "both": ["Consultant", "Entrepreneur", "Academic"]
    }
}, {
    "question":
    "Are you interested in working in a high-stress environment? (Type 'yes' or 'no')",
    "options": {
        "yes": ["Stock Broker", "Surgeon", "Emergency Services"],
        "no": ["Academic", "Research Scientist", "Public Relations Specialist"]
    }
}, {
    "question":
    "Do you prefer working with people, data, or things? (Type 'people', 'data', or 'things')",
    "options": {
        "people": ["Human Resources Specialist", "Sales Manager", "Counselor"],
        "data": ["Data Analyst", "Statistician", "IT Specialist"],
        "things": ["Engineer", "Architect", "Cybersecurity Analyst"]
    }
}, {
    "question":
    "What level of education are you willing to pursue? (Type 'high school', 'bachelor's', 'master's', 'doctorate')",
    "options": {
        "high school":
        ["Entry-Level Positions", "Sales Representative"],
        "bachelor's": ["Manager", "Teacher", "Marketing Specialist"],
        "master's": ["Cybersecurity Analyst","IT Specialist","Engineer","Advanced Researcher"],
        "doctorate":
        ["University Professor", "Research Scientist", "Senior Consultant"]
    }
}]

# College information for each career
colleges = {
    "Software Developer": ["MIT", "Stanford University", "Carnegie Mellon University", "IIT Bombay", "IIT Delhi", "NIT Trichy"],
    "Data Scientist": ["Harvard University", "University of California, Berkeley", "IIT Kharagpur", "IIM Bangalore", "NIT Surathkal"],
    "Cybersecurity Analyst": ["University of Maryland", "Georgia Institute of Technology", "IIT Madras", "NIT Rourkela"],
    "Cloud Engineer": ["University of California, Berkeley", "IIT Hyderabad", "NIT Warangal", "Georgia Institute of Technology", "University of Washington", "University of Maryland", "Stanford University", "MIT", "Cornell University", "University of Illinois at Urbana-Champaign", "Purdue University"],
    "Graphic Designer": ["Rhode Island School of Design", "NID Ahmedabad", "IIT Bombay"],
    "Content Creator": ["New York University", "University of Southern California", "Symbiosis Institute of Design"],
    "Photographer": ["ArtCenter College of Design", "NID Ahmedabad", "Film and Television Institute of India"],
    "Biologist": ["Harvard University", "IISc Bangalore", "IIT Bombay"],
    "Chemist": ["University of California, Berkeley", "IIT Delhi", "IIT Kanpur"],
    "Physicist": ["Princeton University", "IIT Kharagpur", "IISc Bangalore"],
    "Marketing Manager": ["University of Pennsylvania", "IIM Ahmedabad", "IIM Calcutta"],
    "Financial Analyst": ["University of Chicago", "IIM Bangalore", "IIM Lucknow"],
    "Entrepreneur": ["Stanford University", "Harvard Business School", "IIM Ahmedabad"],
    "Doctor": ["AIIMS New Delhi", "All India Institute of Medical Sciences (AIIMS)", "Christian Medical College Vellore"],
    "Dentist": ["Manipal University", "Maulana Azad Institute of Dental Sciences", "IADH Bangalore"],
    "Pharmacist": ["Jamia Hamdard", "IIT Kharagpur", "Manipal College of Pharmaceutical Sciences"],
    "Human Resources Specialist": ["IIM Bangalore", "IIM Calcutta", "XLRI Jamshedpur"],
    "Engineer": ["MIT", "IIT Bombay", "IIT Delhi", "NIT Tiruchirappalli"],
    "Consultant": ["Harvard Business School", "IIM Ahmedabad", "IIM Calcutta"],
    "Research Scientist": ["MIT", "IISc Bangalore", "IIT Bombay"],
    "Public Relations Specialist": ["University of Southern California", "IIM Lucknow", "Symbiosis Institute of Media and Communication"],
    "Sales Manager": ["IIM Ahmedabad", "IIM Bangalore", "XLRI Jamshedpur"],
    "Teacher": ["Harvard University", "Jamia Millia Islamia", "University of Delhi"],
    "Project Manager": ["IIM Bangalore", "IIM Ahmedabad", "XLRI Jamshedpur"],
    "Team Lead": ["Harvard Business School", "IIM Calcutta", "IIM Lucknow"],
    "Academic": ["Harvard University", "IISc Bangalore", "IIT Delhi"],
    "Statistician": ["IISc Bangalore", "University of Chicago", "IIT Kanpur"],
    "IT Specialist": ["IIT Bombay", "NIT Karnataka", "IIIT Hyderabad"],
    "Architect": ["IIT Kharagpur", "NIT Calicut", "CEPT University"],
    "Surgeon": ["AIIMS New Delhi", "Christian Medical College Vellore", "JIPMER Puducherry"],
    "Stock Broker": ["IIM Ahmedabad", "University of Pennsylvania", "University of Chicago"],
    "Emergency Services": ["George Washington University", "NIT Delhi", "IIT Roorkee"]
}

@app.route('/')
def index():
    return render_template('index.html', questions=questions)

@app.route('/submit', methods=['POST'])
def submit():
    data = request.json
    responses = data.get('responses', {})
    suggestions = set()

    for q, answers in responses.items():
        options = next((item["options"]
                        for item in questions if item["question"] == q), {})
        for answer in answers:
            if answer in options:
                suggestions.update(options[answer])

    return jsonify({"suggestions": list(suggestions)})

@app.route('/colleges/<career>', methods=['GET'])
def get_colleges(career):
    colleges_for_career = colleges.get(career, [])
    return jsonify({"colleges": colleges_for_career})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=3000)